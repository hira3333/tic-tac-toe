/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tictac;

/**
 *
 * @author msi
 */
public class TicTac {

    public static void main(String[] args) {
        TicTacToeGame ob = new TicTacToeGame();
        ob.setVisible(true);
    }
}
